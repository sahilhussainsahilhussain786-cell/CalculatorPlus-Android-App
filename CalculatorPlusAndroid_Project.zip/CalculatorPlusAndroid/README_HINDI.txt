CALCULATOR PLUS - ANDROID PROJECT

Is folder mein Calculator Plus ka Android Studio project hai.
Features: Standard calculator, Scientific functions, calculation history, light/dark theme,
copy answer aur memory buttons. App offline chalne ke liye HTML asset ke roop mein bundled hai.

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio mein is extracted folder (CalculatorPlusAndroid) ko Open karein.
3. Gradle sync poora hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
5. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.

Note: Yeh source project hai, pehle se compiled APK nahi. APK compile karne ke liye Android SDK/Android Studio chahiye.
